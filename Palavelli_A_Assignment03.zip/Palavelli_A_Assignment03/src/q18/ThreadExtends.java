package q18;

public class ThreadExtends {

	public static void main(String[] args) {
		Thread th = new Thread(() -> {
		    System.out.println("Thread started");
		});

		th.start(); // starts the thread
		th.start(); // throws IllegalThreadStateException

	}

}
