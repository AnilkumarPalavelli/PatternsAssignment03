package q7;

public class FinalCon {
	
	private String name;

	/**
	 * @param name
	 */
	final public FinalCon(String name) {
		super();
		this.name = name;
	}
	
	

}
