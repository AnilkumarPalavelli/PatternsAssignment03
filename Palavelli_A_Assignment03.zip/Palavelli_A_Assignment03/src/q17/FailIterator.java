/**
 * 
 */
package q17;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author S549406
 *
 */
public class FailIterator {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		list.add("Anil");
		list.add("Palavelli");

		Iterator<String> failFastIterator = list.iterator();
		Iterator<String> failSafeIterator = new CopyOnWriteArrayList<>(list).iterator();

		// Concurrent modification with fail-fast iterator
		failFastIterator.next();
		list.add("Nani");
		failFastIterator.next(); // throws ConcurrentModificationException

		// Concurrent modification with fail-safe iterator
		failSafeIterator.next();
		list.add("Kumar");
		failSafeIterator.next(); // does not throw ConcurrentModificationException


	}

}
