/**
 * 
 */
package q6;

/**
 * @author S549406
 *
 */
public class StringClass {

	/**
	 * @param args
	 */
	public static void main(String [] args) {
		// Using String class
		String str = "Hello";
		str = str+ " Anil";
		System.out.println(str);

		// Using StringBuffer class
		StringBuffer sb = new StringBuffer("Hi");
		sb.append(" Palavelli ");
		System.out.println(sb);

	}

}
