package q3;

public class red extends Color {
	@Override
	public red getSelf() {
		return this;
	}

}
