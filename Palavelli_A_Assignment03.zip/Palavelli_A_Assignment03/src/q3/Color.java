package q3;

public class Color {
	public Color getSelf() {
		return this;
	}

}
