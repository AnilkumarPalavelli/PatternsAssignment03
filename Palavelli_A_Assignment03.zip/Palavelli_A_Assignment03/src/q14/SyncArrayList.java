/**
 * 
 */
package q14;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author S549406
 *
 */
public class SyncArrayList {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		List<String> synchronizedList = Collections.synchronizedList(list);
		list.add("Anil");
		System.out.println(list);
		
		
		List<String> list2 = new CopyOnWriteArrayList<>();
		list2.add("Palavelli");
		System.out.println(list2);

	}

}
