/**
 * 
 */
package q15;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

/**
 * @author S549406
 *
 */
public class HashDriver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Hashtable<String, Integer> table = new Hashtable<>();
		table.put("Missouri", 64468);
		table.put("Texas", 234456);
		table.put("Iowa", 64469);
		
		System.out.println(table);

		HashMap<String, Integer> map = new HashMap<>();
		map.put("one", 1);
		map.put("two", 2);
		map.put("three", 3);
		
		System.out.println(map);
		
		

	}

}
