package q8;

public class TryBlockWithoutCatch {

	public static void main(String[] args) {
		try {
	         
	      } finally {
	         
	      }

	}

}
