package q19;

public class threadsnine {

	public static void main(String[] args) {
		MyThread th = new MyThread();
		th.start();
		
		MyRunnable run = new MyRunnable();
		Thread th1 = new Thread(run);
		th1.start();
	}

}

      // Extend Thread class
     class MyThread extends Thread {
	 @Override
	 public void run() {
		
	}
}

    // Implement Runnable interface
    class MyRunnable implements Runnable {
	@Override
	public void run() {
		

	}

}
