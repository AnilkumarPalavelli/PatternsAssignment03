package q12;

public class FinallyDriver {

	public static void main(String[] args) {
		final String lname = "Palavelli";
		String fname = "Anil"; // This will cause a compilation error because x is final

		try {
		    // some code that may throw an exception
		} catch (Exception e) {
		    // handle the exception
		} finally {
		    // this code will always be executed
		}

	}
	@Override
	 protected void finalize() throws Throwable {
	    // perform some cleanup here
	    super.finalize();
	 }
}
