package q2;

public class Animal {
	public void makeSound() {
        System.out.println("The animal is making some sound");
    }
	
	protected  void color() {
		System.out.println("The color of the Animal is");
		
	}
	
	void iswild() {
		System.out.println("Is this Animal wild");
	}

}
