package q2;

public class Cat extends Animal {
	
	public void makeSound() {
        System.out.println("The cat makes meow meow sound");
    }
	
	protected  void iswild() {
		System.out.println("It is not a wild animal");
		
		
	}

}
