package q5;

public class Strings {

	public static void main(String[] args) {
		// Using StringBuffer
		StringBuffer sbf = new StringBuffer("Hello");
		sbf.append(" Anil");
		System.out.println(sbf); 

		// Using StringBuilder
		StringBuilder sb1 = new StringBuilder("Hi");
		sb1.append(" Palavelli");
		System.out.println(sb1);

	}

}
