/**
 * 
 */
package q1;

/**
 * @author S549406
 *
 */
public class Generics<T> {

	private T name;

	/**
	 * @param name
	 */
	public Generics(T name) {
		super();
		this.name = name;
	}

	/**
	 * @return the name
	 */
	public T getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(T name) {
		this.name = name;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Generics<String> c1 = new Generics<String>("Anil");
		System.out.println("The name of the String is :" + c1.getName());

	}

}
