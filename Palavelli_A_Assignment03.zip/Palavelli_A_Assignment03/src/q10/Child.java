package q10;



public class Child extends Parent {
	public void doHappy() {
		
		
	}
}
