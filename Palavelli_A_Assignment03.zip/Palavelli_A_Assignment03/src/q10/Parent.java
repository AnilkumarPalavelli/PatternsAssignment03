package q10;

import java.io.IOException;

public class Parent {
	public void doHappy() throws IOException {
		
		
	}

}
