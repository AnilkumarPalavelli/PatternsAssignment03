package q4;

public class ColorDriver {

	public static void main(String[] args) {
		Color c1= new red();
		c1.israin();

	}

}
