package q4;

public class red extends Color {
	private static void Type() {
		System.out.println("Red");
	}
	
	@Override
	public void israin() {
		Type();
		System.out.println("no");
	}

}
