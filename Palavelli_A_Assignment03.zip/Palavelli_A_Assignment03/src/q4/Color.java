package q4;

public class Color {
	private static void Type() {
		System.out.println("Color");
		
	}
	
	public void israin() {
		Type();
		System.out.println("It is not rainbow");
	}

}
