package q13;

import java.util.ArrayList;
import java.util.Vector;

public class ArrayListVectorDriver {

	public static void main(String[] args) {
		Vector<String> vector = new Vector<>();
		vector.add("Anil");
		vector.add("Hari");
		vector.add("Bhanu");
		System.out.println(vector);
		
		
		ArrayList<String> list = new ArrayList<>();
		list.add("Krishna");
		list.add("Samyuktha");
		list.add("Srinidhi");
		System.out.println(list);

	}

}
