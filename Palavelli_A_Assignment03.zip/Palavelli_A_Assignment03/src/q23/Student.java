package q23;

public final class Student {
	private final int sid;
    private final String name;
	/**
	 * @param sid
	 * @param name
	 */
	public Student(int sid, String name) {
		super();
		this.sid = sid;
		this.name = name;
	}
	/**
	 * @return the sid
	 */
	public int getSid() {
		return sid;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

}
